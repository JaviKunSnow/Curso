package config;

public class Conexion {

}
