import controller.HomeController;

public class index {

	public static void main(String[] args) {
		
		HomeController homeController = new HomeController();
		
		homeController.llamadaInicial();

	}

}
